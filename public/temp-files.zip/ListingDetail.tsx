import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { getListing, DEMO_USERS } from '@/lib/data';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { ShoppingCart, ArrowLeft, Package, Shield, MessageCircle, Loader2, KeyRound, AlertTriangle, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { PriceDisplay } from '@/components/PriceDisplay';
import { useAuth } from '@/hooks/useAuth';
import { usePrivateKeyAuth } from '@/hooks/usePrivateKeyAuth';
import { useExchangeRate } from '@/hooks/useExchangeRate';
import { SellerCard } from '@/components/SellerCard';
import { ImageGallery } from '@/components/ImageGallery';
import { startConversation } from '@/hooks/useMessages';
import { createOrder } from '@/hooks/useOrders';
import { usePGP } from '@/hooks/usePGP';
import { PGPPassphraseDialog } from '@/components/PGPPassphraseDialog';
import { Listing } from '@/lib/types';

const ListingDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { privateKeyUser } = usePrivateKeyAuth();
  const { usdToXmr } = useExchangeRate();
  const { 
    isUnlocked, 
    checkHasKeys, 
    encryptMessage, 
    getRecipientPublicKey,
    restoreSession 
  } = usePGP();
  
  const [listing, setListing] = useState<(Listing & { isDbListing?: boolean }) | null>(null);
  const [loadingListing, setLoadingListing] = useState(true);
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [showBuyDialog, setShowBuyDialog] = useState(false);
  const [showPGPDialog, setShowPGPDialog] = useState(false);
  const [message, setMessage] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  
  // PGP status tracking
  const [buyerHasPGP, setBuyerHasPGP] = useState(false);
  const [sellerHasPGP, setSellerHasPGP] = useState(false);
  const [sellerPublicKey, setSellerPublicKey] = useState<string | null>(null);
  const [checkingPGP, setCheckingPGP] = useState(false);
  const [pendingAction, setPendingAction] = useState<'buy' | 'contact' | null>(null);

  const isAuthenticated = !!user || !!privateKeyUser;

  // Restore PGP session on mount
  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  // Fetch listing from Supabase first, then fallback to demo
  useEffect(() => {
    const fetchListing = async () => {
      if (!id) return;
      
      setLoadingListing(true);
      
      // Try Supabase first
      const { data: dbListing, error } = await supabase
        .from('listings')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      
      if (dbListing && !error) {
        setListing({
          id: dbListing.id,
          sellerId: dbListing.seller_id,
          title: dbListing.title,
          description: dbListing.description,
          priceUsd: dbListing.price_usd,
          category: dbListing.category,
          images: dbListing.images?.length > 0 ? dbListing.images : ['/placeholder.svg'],
          stock: dbListing.stock,
          shippingPriceUsd: dbListing.shipping_price_usd,
          status: dbListing.status as 'active' | 'sold_out' | 'draft',
          condition: dbListing.condition as 'new' | 'used' | 'digital',
          createdAt: dbListing.created_at,
          isDbListing: true
        });
        
        // Increment view count for DB listings (fire and forget)
        (async () => {
          try {
            await supabase.rpc('increment_listing_views', { listing_id: id });
          } catch (e) {
            console.error('Failed to increment views:', e);
          }
        })();
      } else {
        // Fallback to demo listings
        const demoListing = getListing(id);
        setListing(demoListing || null);
      }
      
      setLoadingListing(false);
    };
    
    fetchListing();
  }, [id]);

  // Check PGP status for buyer and seller when listing loads
  useEffect(() => {
    const checkPGPStatus = async () => {
      if (!listing || !isAuthenticated) return;
      
      setCheckingPGP(true);
      
      // Check buyer's PGP status
      const buyerHasKeys = await checkHasKeys();
      setBuyerHasPGP(buyerHasKeys);
      
      // Check seller's PGP status (for DB listings)
      if (listing.isDbListing) {
        const { data: sellerProfile } = await supabase
          .from('profiles')
          .select('pgp_public_key')
          .eq('id', listing.sellerId)
          .maybeSingle();
        
        if (sellerProfile?.pgp_public_key) {
          setSellerHasPGP(true);
          setSellerPublicKey(sellerProfile.pgp_public_key);
        } else {
          setSellerHasPGP(false);
          setSellerPublicKey(null);
        }
      } else {
        // Demo listings - assume seller has PGP for testing
        setSellerHasPGP(true);
        setSellerPublicKey(null);
      }
      
      setCheckingPGP(false);
    };
    
    checkPGPStatus();
  }, [listing, isAuthenticated, checkHasKeys]);

  const seller = listing ? DEMO_USERS.find(u => u.id === listing.sellerId) : null;

  // Handle Buy Now click with PGP checks
  const handleBuyClick = async () => {
    if (!isAuthenticated) {
      toast.error('Please sign in to make a purchase');
      navigate('/auth');
      return;
    }

    // Check if buyer has PGP keys
    if (!buyerHasPGP) {
      toast.error('PGP encryption required', {
        description: 'Please set up PGP keys in Settings to make purchases'
      });
      navigate('/settings');
      return;
    }

    // Check if seller has PGP keys (for real listings)
    if (listing?.isDbListing && !sellerHasPGP) {
      toast.error('Seller has not set up encryption', {
        description: 'Cannot purchase from sellers without PGP keys'
      });
      return;
    }

    // Check if buyer's PGP is unlocked
    if (!isUnlocked) {
      setPendingAction('buy');
      setShowPGPDialog(true);
      return;
    }

    // All checks passed, show buy dialog
    setShowBuyDialog(true);
  };

  // Handle PGP unlock completion
  const handlePGPUnlocked = () => {
    setShowPGPDialog(false);
    if (pendingAction === 'buy') {
      setShowBuyDialog(true);
    } else if (pendingAction === 'contact') {
      setShowContactDialog(true);
    }
    setPendingAction(null);
  };

  const handleContactSeller = async () => {
    if (!user) {
      toast.error('Please sign in to contact seller');
      navigate('/auth');
      return;
    }

    if (!message.trim()) {
      toast.error('Please enter a message');
      return;
    }

    setLoading(true);
    const conversationId = await startConversation(
      listing!.id,
      listing!.sellerId,
      user.id,
      message.trim()
    );
    setLoading(false);

    if (conversationId) {
      toast.success('Message sent!');
      setShowContactDialog(false);
      setMessage('');
      navigate(`/messages/${conversationId}`);
    } else {
      toast.error('Failed to send message');
    }
  };

  const handleBuyNow = async () => {
    if (!user || !listing) {
      toast.error('Please sign in to make a purchase');
      navigate('/auth');
      return;
    }

    if (listing.stock < quantity) {
      toast.error('Not enough stock available');
      return;
    }

    if (!shippingAddress.trim()) {
      toast.error('Please enter a shipping address');
      return;
    }

    setLoading(true);

    try {
      // Encrypt shipping address with seller's public key
      let encryptedShippingAddress = shippingAddress.trim();
      
      if (sellerPublicKey && isUnlocked) {
        const encrypted = await encryptMessage(shippingAddress.trim(), sellerPublicKey);
        if (encrypted) {
          encryptedShippingAddress = encrypted;
          console.log('Shipping address encrypted successfully');
        } else {
          console.warn('Failed to encrypt shipping address, storing plaintext');
          toast.warning('Could not encrypt shipping address', {
            description: 'Address will be stored in plaintext'
          });
        }
      } else if (listing.isDbListing) {
        console.warn('No seller public key available for encryption');
      }

      const totalPrice = (listing.priceUsd * quantity) + listing.shippingPriceUsd;

      const orderId = await createOrder(
        listing.id,
        listing.sellerId,
        false, // assuming sellers are regular users
        quantity,
        listing.priceUsd,
        listing.shippingPriceUsd,
        encryptedShippingAddress
      );

      if (orderId) {
        // Auto-start encrypted conversation with order details
        const orderMessage = `New order placed!\n\nOrder ID: ${orderId}\nItem: ${listing.title}\nQuantity: ${quantity}\nTotal: $${totalPrice.toFixed(2)} (≈ ${usdToXmr(totalPrice).toFixed(6)} XMR)\n\nShipping address has been encrypted and attached to the order.`;
        
        await startConversation(
          listing.id,
          listing.sellerId,
          user.id,
          orderMessage
        );

        toast.success('Order created!', {
          description: 'Redirecting to checkout...'
        });
        setShowBuyDialog(false);
        navigate(`/checkout/${orderId}`);
      } else {
        toast.error('Failed to create order');
      }
    } catch (error) {
      console.error('Error creating order:', error);
      toast.error('Failed to create order');
    } finally {
      setLoading(false);
    }
  };

  if (loadingListing) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto" />
          <p className="mt-4 text-muted-foreground">Loading listing...</p>
        </div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold mb-4">Listing not found</h1>
          <Link to="/browse">
            <Button>Back to Browse</Button>
          </Link>
        </div>
      </div>
    );
  }

  const totalPrice = (listing.priceUsd * quantity) + listing.shippingPriceUsd;

  // Determine if buy button should be disabled and why
  const getBuyButtonState = () => {
    if (listing.stock < 1) {
      return { disabled: true, reason: 'Sold Out' };
    }
    if (checkingPGP) {
      return { disabled: true, reason: 'Checking encryption...' };
    }
    if (isAuthenticated && !buyerHasPGP) {
      return { disabled: false, reason: 'Setup Required' };
    }
    if (listing.isDbListing && !sellerHasPGP) {
      return { disabled: true, reason: 'Seller Not Ready' };
    }
    return { disabled: false, reason: null };
  };

  const buyButtonState = getBuyButtonState();

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate('/browse')}
          className="mb-6 gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Browse
        </Button>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Image Gallery */}
          <div>
            <ImageGallery images={listing.images} title={listing.title} />
          </div>

          {/* Details */}
          <div>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex gap-2 mb-2">
                  <Badge>{listing.category}</Badge>
                  {!listing.isDbListing && <Badge variant="secondary">Demo Listing</Badge>}
                </div>
                <h1 className="text-4xl font-bold mb-2">{listing.title}</h1>
              </div>
            </div>

            <div className="mb-6">
              <PriceDisplay 
                usdAmount={listing.priceUsd} 
                className="text-4xl font-bold text-primary block mb-2"
              />
              {listing.shippingPriceUsd > 0 && (
                <div className="text-muted-foreground flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  <PriceDisplay usdAmount={listing.shippingPriceUsd} /> shipping
                </div>
              )}
            </div>

            <Card className="mb-6">
              <CardContent className="p-6">
                <h2 className="font-semibold mb-3">Description</h2>
                <p className="text-muted-foreground leading-relaxed">
                  {listing.description}
                </p>
              </CardContent>
            </Card>

            {/* Seller Card */}
            {seller && (
              <div className="mb-6">
                <h2 className="font-semibold mb-3">Seller</h2>
                <SellerCard seller={seller} />
              </div>
            )}

            <div className="flex items-center gap-4 mb-6 flex-wrap">
              <Badge variant={listing.stock > 0 ? 'default' : 'destructive'} className="text-base py-2 px-4">
                {listing.stock > 0 ? `${listing.stock} in stock` : 'Sold Out'}
              </Badge>
              {/* PGP Status Indicators */}
              {isAuthenticated && (
                <div className="flex gap-2 flex-wrap">
                  {buyerHasPGP ? (
                    <Badge variant="outline" className="gap-1 text-green-600 border-green-600">
                      <Lock className="w-3 h-3" /> Your PGP Ready
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="gap-1 text-amber-600 border-amber-600">
                      <AlertTriangle className="w-3 h-3" /> Setup PGP
                    </Badge>
                  )}
                  {listing.isDbListing && (
                    sellerHasPGP ? (
                      <Badge variant="outline" className="gap-1 text-green-600 border-green-600">
                        <Lock className="w-3 h-3" /> Seller PGP Ready
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="gap-1 text-red-600 border-red-600">
                        <AlertTriangle className="w-3 h-3" /> Seller No PGP
                      </Badge>
                    )
                  )}
                </div>
              )}
            </div>

            {/* PGP Warning if buyer doesn't have keys */}
            {isAuthenticated && !buyerHasPGP && (
              <Alert className="mb-4 border-amber-500/50 bg-amber-500/10">
                <KeyRound className="h-4 w-4 text-amber-500" />
                <AlertDescription className="text-amber-700 dark:text-amber-300">
                  PGP encryption is required to make purchases. Your shipping address will be encrypted so only the seller can read it.{' '}
                  <Link to="/settings" className="underline font-medium">
                    Set up PGP keys in Settings →
                  </Link>
                </AlertDescription>
              </Alert>
            )}

            {/* Warning if seller doesn't have PGP */}
            {listing.isDbListing && !sellerHasPGP && (
              <Alert className="mb-4 border-red-500/50 bg-red-500/10">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <AlertDescription className="text-red-700 dark:text-red-300">
                  This seller has not set up PGP encryption. Purchases are currently disabled for your protection.
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-4">
              <div className="flex gap-3">
                <Button
                  size="lg"
                  className="flex-1 gap-2 text-lg"
                  onClick={handleBuyClick}
                  disabled={buyButtonState.disabled}
                >
                  {checkingPGP ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <ShoppingCart className="w-5 h-5" />
                  )}
                  {buyButtonState.reason || 'Buy Now'}
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => {
                    if (!isAuthenticated) {
                      toast.error('Please sign in to contact seller');
                      navigate('/auth');
                      return;
                    }
                    setShowContactDialog(true);
                  }}
                >
                  <MessageCircle className="w-5 h-5" />
                </Button>
              </div>

              <Card className="bg-primary/10 border-primary/20">
                <CardContent className="p-4 flex items-start gap-3">
                  <Shield className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <div className="font-semibold text-foreground mb-1">End-to-End Encrypted</div>
                    <div className="text-muted-foreground">
                      Your shipping address is PGP-encrypted before being stored. Only the seller can decrypt it.
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* PGP Passphrase Dialog */}
      <PGPPassphraseDialog 
        open={showPGPDialog} 
        onOpenChange={setShowPGPDialog}
        onUnlocked={handlePGPUnlocked}
      />

      {/* Contact Seller Dialog */}
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contact Seller</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Send a message to {seller?.displayName || 'the seller'} about "{listing.title}"
              </p>
              <Textarea
                placeholder="Hi, I'm interested in this item..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowContactDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleContactSeller} disabled={loading || !message.trim()}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Send Message
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Buy Now Dialog */}
      <Dialog open={showBuyDialog} onOpenChange={setShowBuyDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              Secure Purchase
            </DialogTitle>
            <DialogDescription>
              Your shipping address will be encrypted with the seller's PGP key
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
              {listing.images[0] && (
                <img
                  src={listing.images[0]}
                  alt={listing.title}
                  className="w-16 h-16 object-cover rounded"
                />
              )}
              <div className="flex-1">
                <p className="font-semibold">{listing.title}</p>
                <p className="text-sm text-muted-foreground">
                  ${listing.priceUsd.toFixed(2)} each
                </p>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Quantity</label>
              <Input
                type="number"
                min={1}
                max={listing.stock}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, Math.min(listing.stock, parseInt(e.target.value) || 1)))}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block flex items-center gap-2">
                <Lock className="w-4 h-4 text-green-500" />
                Shipping Address
                <span className="text-xs text-muted-foreground font-normal">(encrypted)</span>
              </label>
              <Textarea
                placeholder="Enter your full shipping address..."
                value={shippingAddress}
                onChange={(e) => setShippingAddress(e.target.value)}
                rows={3}
              />
              <p className="text-xs text-muted-foreground mt-1">
                🔒 This will be encrypted with the seller's PGP public key
              </p>
            </div>

            <div className="border-t pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal ({quantity} item{quantity > 1 ? 's' : ''})</span>
                <span>${(listing.priceUsd * quantity).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Shipping</span>
                <span>${listing.shippingPriceUsd.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
              <div className="text-sm text-muted-foreground">
                ≈ {usdToXmr(totalPrice).toFixed(6)} XMR
              </div>
            </div>

            {/* Encryption Status */}
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <div className="flex items-center gap-2 text-sm text-green-700 dark:text-green-300">
                <Shield className="w-4 h-4" />
                <span className="font-medium">End-to-end encryption active</span>
              </div>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                A secure conversation will be started with the seller automatically
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBuyDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleBuyNow} disabled={loading || !shippingAddress.trim()}>
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Encrypting & Creating Order...
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Place Secure Order
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ListingDetail;
